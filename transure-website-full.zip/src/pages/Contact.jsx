
export default function Contact({ lang }) {
  return (
    <div style={ padding: '20px' }>
      <h1>{lang === 'ar' ? 'Contact بالعربية' : 'Contact in English'}</h1>
      <p>{lang === 'ar' ? 'محتوى صفحة Contact' : 'Contact page content'}</p>
    </div>
  );
}
