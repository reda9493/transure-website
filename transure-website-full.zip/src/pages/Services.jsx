
export default function Services({ lang }) {
  return (
    <div style={ padding: '20px' }>
      <h1>{lang === 'ar' ? 'Services بالعربية' : 'Services in English'}</h1>
      <p>{lang === 'ar' ? 'محتوى صفحة Services' : 'Services page content'}</p>
    </div>
  );
}
