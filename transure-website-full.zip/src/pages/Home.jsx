
export default function Home({ lang }) {
  return (
    <div style={ padding: '20px' }>
      <h1>{lang === 'ar' ? 'Home بالعربية' : 'Home in English'}</h1>
      <p>{lang === 'ar' ? 'محتوى صفحة Home' : 'Home page content'}</p>
    </div>
  );
}
