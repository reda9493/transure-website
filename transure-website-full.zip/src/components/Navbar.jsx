
import { Link } from 'react-router-dom';

export default function Navbar({ lang, setLang }) {
  const t = {
    en: ['Home', 'About', 'Services', 'FAQ', 'Contact'],
    ar: ['الرئيسية', 'من نحن', 'الخدمات', 'الأسئلة الشائعة', 'تواصل معنا']
  };

  return (
    <nav style={{ backgroundColor: '#222', color: '#fff', padding: '10px' }}>
      <h2>{lang === 'ar' ? 'ترانشور' : 'Transure'}</h2>
      <ul style={{ display: 'flex', gap: '15px' }}>
        <li><Link to="/">{t[lang][0]}</Link></li>
        <li><Link to="/about">{t[lang][1]}</Link></li>
        <li><Link to="/services">{t[lang][2]}</Link></li>
        <li><Link to="/faq">{t[lang][3]}</Link></li>
        <li><Link to="/contact">{t[lang][4]}</Link></li>
        <li><button onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')}>
          {lang === 'ar' ? 'English' : 'العربية'}
        </button></li>
      </ul>
    </nav>
  );
}
