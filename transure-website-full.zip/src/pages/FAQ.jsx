
export default function FAQ({ lang }) {
  return (
    <div style={ padding: '20px' }>
      <h1>{lang === 'ar' ? 'FAQ بالعربية' : 'FAQ in English'}</h1>
      <p>{lang === 'ar' ? 'محتوى صفحة FAQ' : 'FAQ page content'}</p>
    </div>
  );
}
