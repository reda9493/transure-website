
export default function About({ lang }) {
  return (
    <div style={ padding: '20px' }>
      <h1>{lang === 'ar' ? 'About بالعربية' : 'About in English'}</h1>
      <p>{lang === 'ar' ? 'محتوى صفحة About' : 'About page content'}</p>
    </div>
  );
}
